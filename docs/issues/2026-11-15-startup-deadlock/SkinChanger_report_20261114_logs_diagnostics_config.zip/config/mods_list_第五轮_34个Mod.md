# 第五轮第 22 次(19:03 启动，退出卡死)使用的 34 个 Mod

来源：当时 `settings.save` 的 `mod_settings.mod_list`(按文件顺序，只列启用项)。游戏实际加载顺序见日志 22 开头的 `New sorting order`。

| # | id | 名称 | 版本 | 含 DLL | 来源 |
|---|---|---|---|---|---|
| 1 | `STS2-RitsuLib` | RitsuLib | 0.6.12 | 是 | 创意工坊 3747602295 |
| 2 | `Gurio.SkinChanger` | 皮肤切换器-Skin Changer | 1.0.31 | 是 | 创意工坊 3787302680 |
| 3 | `ModConfig` | 皮皮配置: ModConfig | 0.2.4 | 是 | 创意工坊 3747557003 |
| 4 | `DamageMeter` | 皮皮统计: Skada | 1.16.1 | 是 | 创意工坊 3747557283 |
| 5 | `Rewind` | 皮皮倒带: Rewind | 0.26.20 | 是 | 创意工坊 3747557762 |
| 6 | `QuickLink` | 皮皮快连: QuickLink | 0.10.1 | 是 | 创意工坊 3747557834 |
| 7 | `SpeedX` | 皮皮极速: SpeedX | 0.11.12 | 是 | 创意工坊 3747557357 |
| 8 | `BetterModMenu` | Better Mod Menu | 1.1.5 | 是 | 创意工坊 3748029698 |
| 9 | `RegentFX` | 万象辉星[RegentFX] | 0.5.2 | 是 | 创意工坊 3747497501 |
| 10 | `cutenecrobinder-nsfwv0.6` | cutenecrobinder-nsfwv0.6 | v1.0.0 | 是 | 本地 mods/cutenecrobinder-nsfwv0.6 |
| 11 | `AI_silent_NSFW_MOD` | AI_silent_NSFW_MOD | 1.0.3 | 是 | 本地 mods/AI_silent_NSFW_MOD-V1.0.3 |
| 12 | `BaseLibCompatibilityHelper` | BaseLib Compatibility Helper | v0.0.0 | 是 | 创意工坊 3737335127 |
| 13 | `BaseLib` | BaseLib | v3.4.8 | 是 | 创意工坊 3737335127 |
| 14 | `necrobinderHpWear` | 骨妹四档血量换装[fourform] | 1.0.70 | 是 | 本地 mods/雪霁&森森&Kira改 a骨妹可战损版 |
| 15 | `regentHpWear` | 储君皮肤 Mesugaki（含血量战损换装）[107] | 0.7.55 | 是 | 本地 mods/雪霁&森森改 韩国储君可战损版 |
| 16 | `defectHpWear` | 机器人皮肤 MechaNeko（含血量战损换装）[107] | 0.7.65 | 是 | 本地 mods/雪霁&森森改 韩国机器人可战损版 |
| 17 | `succubusIroncladHpWear` | 魅魔战士血量换装[两档] | 1.0.26 | 是 | 本地 mods/雪霁&森森改 魅魔战士可战损版 |
| 18 | `CuteNecrobinder-Cards-Rework-nsfw` | CuteNecrobinder-Cards-Rework-nsfw | 0.0.1 | 否 | 本地 mods/CuteNecrobinder-Cards-Rework-nsfw(1) |
| 19 | `CNRRegentCards` | CNRRegentCards | v5.26 | 否 | 本地 mods/cnr卡面整合 |
| 20 | `CNRIroncladCards` | CNRIroncladCards | v5.29 | 否 | 本地 mods/cnr卡面整合 |
| 21 | `CNRDefectCards` | CNRDefectCards | v5.19 | 否 | 本地 mods/cnr卡面整合 |
| 22 | `CNRSilentCards` | CNRSilentCards | v5.29 | 否 | 本地 mods/cnr卡面整合 |
| 23 | `CNROtherCards` | CNROtherCards | v5.29 | 否 | 本地 mods/cnr卡面整合 |
| 24 | `CNRNecrobinderCards` | CNRNecrobindertCards | v6.27 | 否 | 本地 mods/cnr卡面整合 |
| 25 | `RTRsMoeifyMod_cards` | RTRsMoeifyMod_cards | v0.2.0 | 是 | 本地 mods/cnr卡面整合 |
| 26 | `N1.1` | N1.1 | v1.0.0 | 是 | 本地 mods/两期N版卡图筛选整合版-Ver1.1 |
| 27 | `卡图合集i站n版卡图2.0` | 卡图合集i站n版卡图2.0 | v1.0.0 | 是 | 本地 mods/卡图合集i站n版卡图2.0神秘小循环整合 |
| 28 | `MesugakiRegentCards` | 储君 Mesugaki 卡图 | 1.0.0 | 否 | 创意工坊 3837165398 |
| 29 | `NecroCardArtPortraits` | Necro Card Art | 0.2.0 | 是 | 创意工坊 3830638493 |
| 30 | `No color cards lewd full feminization complete version` | No color cards lewd full feminization complete version | 1.0 | 是 | 创意工坊 3819593207 |
| 31 | `Pornographic beautification of all cards v2.1` | Pornographic beautification of all cards v2.1 | 2.1 | 是 | 创意工坊 3773072493 |
| 32 | `Moe-Necrobinder` | Moe-Necro | 0.1.1 | 否 | 本地 mods/森森自用 韩国大扔扔骨妹NSFW |
| 33 | `JoanofArcIroncladHpwear` | 战士贞德 血量换装 | 0.3.16 | 是 | 本地 mods/雪霁&森森&青霄改 贞德战士可战损版 |
| 34 | `ironcladHpWear` | 战士血量换装[107–111] | 1.0.85 | 是 | 本地 mods/雪霁&森森改 驼鹿战士可战损版 |
