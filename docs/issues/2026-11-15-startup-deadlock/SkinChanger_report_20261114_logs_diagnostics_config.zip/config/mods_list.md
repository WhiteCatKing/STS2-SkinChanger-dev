# 加载顺序与 Mod 列表(取自日志 05,即 SkinChanger 开启时的最后一次卡死会话)

| 顺序 | id | 名称 | 版本 | min_game_version | 来源 |
|---|---|---|---|---|---|
| 0 | `ModCompatLayer` | 模组兼容层 | 1.1.0 |  | workshop |
| 1 | `STS2-RitsuLib` | RitsuLib | 0.6.12 | 0.107.1 | workshop |
| 2 | `ModConfig` | 皮皮配置: ModConfig | 0.2.4 |  | workshop |
| 3 | `汐の雨い 半血爆衣 野猪娘化 jlzzzs` | 汐の雨い 半血爆衣 野猪娘化 jlzzzs | 1.0.0 |  | mods目录 |
| 4 | `汐の雨い 半血爆衣 lhsn` | 汐の雨い 半血爆衣 lhsn | 1.0.30 |  | mods目录 |
| 5 | `DamageMeter` | 皮皮统计: Skada | 1.16.1 |  | workshop |
| 6 | `Rewind` | 皮皮倒带: Rewind | 0.26.20 |  | workshop |
| 7 | `QuickLink` | 皮皮快连: QuickLink | 0.10.1 |  | workshop |
| 8 | `SpeedX` | 皮皮极速: SpeedX | 0.11.12 |  | workshop |
| 9 | `PaelMod` | 7.2-3.先古佩尔动态(🌸花自改N) | v0.2.0 |  | mods目录 |
| 10 | `RTRsMoeifyModN` | 7.3-6.钻地.猎杀等6怪(🌸花自改N) | v0.2.0 |  | mods目录 |
| 11 | `UnblockedHitSfx` | NSFW受击与受伤音效 | 1.7.0 | 0.107.1 | mods目录 |
| 12 | `NSFW-Event` | NSFW化原版事件 | V1.0 |  | workshop |
| 13 | `CNRcampfire` | CNRcampfire | v5.18 |  | mods目录 |
| 14 | `neowSkin` | neowSkin | 0.0.1 |  | mods目录 |
| 15 | `voicemod` | VoiceModFramework | 1.0.0 |  | mods目录 |
| 16 | `Merchant2CuteII` | Merchant2CuteII | v1.4.1 |  | mods目录 |
| 17 | `Moe-Necrobinder` | Moe-Necro | 0.1.1 |  | mods目录 |
| 18 | `锭_grayingot sfw ljwlzm` | 锭_grayingot sfw ljwlzm | 0.0.4 |  | mods目录 |
| 19 | `会画画的Small_day sfw 无手 yss` | 会画画的Small_day sfw 无手 yss | 2.0 |  | mods目录 |
| 20 | `会画画的Small_day sfw 有手 yss` | 会画画的Small_day sfw 有手 yss | 2.0 |  | mods目录 |
| 21 | `锭_grayingot nsfw yss` | 锭_grayingot nsfw yss | 0.0.4 |  | mods目录 |
| 22 | `锭_grayingot sfw yss` | 锭_grayingot sfw yss | 0.0.4 |  | mods目录 |
| 23 | `1987的某一天 sfw tqcm` | 1987的某一天 sfw tqcm | v0.2.0 |  | mods目录 |
| 24 | `anaertailin nsfw 半全裸 jlzns` | anaertailin nsfw 半全裸 jlzns | 1.0.0 |  | mods目录 |
| 25 | `anaertailin nsfw 去裙子 jlzns` | anaertailin nsfw 去裙子 jlzns | 1.0.0 |  | mods目录 |
| 26 | `anaertailin nsfw 带裙子 jlzns` | anaertailin nsfw 带裙子 jlzns | 1.0.0 |  | mods目录 |
| 27 | `anaertailin sfw jlzns` | anaertailin sfw jlzns | 0.0.1 |  | mods目录 |
| 28 | `anaertailin nsfw 桂冠 - 全卸甲 jlzbt` | anaertailin nsfw 桂冠 - 全卸甲 jlzbt | 1.0.0 |  | mods目录 |
| 29 | `anaertailin nsfw 桂冠 - 半卸甲 jlzbt` | anaertailin nsfw 桂冠 - 半卸甲 jlzbt | 1.0.0 |  | mods目录 |
| 30 | `anaertailin nsfw 蒙面 - 全卸甲 jlzbt` | anaertailin nsfw 蒙面 - 全卸甲 jlzbt | 1.0.0 |  | mods目录 |
| 31 | `anaertailin nsfw 蒙面 - 半卸甲 jlzbt` | anaertailin nsfw 蒙面 - 半卸甲 jlzbt | 1.0.0 |  | mods目录 |
| 32 | `anaertailin sfw jlzbt` | anaertailin sfw jlzbt | 0.0.1 |  | mods目录 |
| 33 | `汐の雨い sfw 野猪娘化 jlzzzs` | 汐の雨い sfw 野猪娘化 jlzzzs | 1.0.0 |  | mods目录 |
| 34 | `锭_grayingot sfw tzxt` | 锭_grayingot sfw tzxt | 0.0.4 |  | mods目录 |
| 35 | `锭_grayingot sfw tzsg` | 锭_grayingot sfw tzsg | 0.0.4 |  | mods目录 |
| 36 | `1987的某一天 sfw ddc` | 1987的某一天 sfw ddc | v0.2.0 |  | mods目录 |
| 37 | `anaertailin nsfw myhl` | anaertailin nsfw myhl | 1.2.1 |  | mods目录 |
| 38 | `anaertailin nsfw 红脸 myhl` | anaertailin nsfw 红脸 myhl | 1.2.1 |  | mods目录 |
| 39 | `anaertailin sfw myhl` | anaertailin sfw myhl | 1.2.1 |  | mods目录 |
| 40 | `anaertailin 破滑溜爆衣半血红脸 myhl` | anaertailin 破滑溜爆衣半血红脸 myhl | 1.2.1 |  | mods目录 |
| 41 | `锭_grayingot sfw myhl` | 锭_grayingot sfw myhl | 0.0.4 |  | mods目录 |
| 42 | `会画画的Small_day nsfw 普通 dnsyn` | 会画画的Small_day nsfw 普通 dnsyn | 2.0 |  | mods目录 |
| 43 | `会画画的Small_day nsfw 纹身 dnsyn` | 会画画的Small_day nsfw 纹身 dnsyn | 2.0 |  | mods目录 |
| 44 | `会画画的Small_day sfw dnsyn` | 会画画的Small_day sfw dnsyn | 2.0 |  | mods目录 |
| 45 | `会画画的Small_day nsfw nw` | 会画画的Small_day nsfw nw | 2.0 |  | mods目录 |
| 46 | `会画画的Small_day sfw nw` | 会画画的Small_day sfw nw | 2.0 |  | mods目录 |
| 47 | `佚名 sfw 原版特效 ywjsc` | 佚名 sfw 原版特效 ywjsc | 1.0.0 |  | mods目录 |
| 48 | `佚名 sfw 无特效 ywjsc` | 佚名 sfw 无特效 ywjsc | 1.0.0 |  | mods目录 |
| 49 | `会画画的Small_day sfw ym` | 会画画的Small_day sfw ym | 2.0 |  | mods目录 |
| 50 | `会画画的Small_day nsfw ynbb` | 会画画的Small_day nsfw ynbb | 2.0 |  | mods目录 |
| 51 | `会画画的Small_day sfw ynbb` | 会画画的Small_day sfw ynbb | 2.0 |  | mods目录 |
| 52 | `1987的某一天 sfw grlz` | 1987的某一天 sfw grlz | v0.2.0 |  | mods目录 |
| 53 | `佚名 sfw 未娘化 ndc` | 佚名 sfw 未娘化 ndc | 1.0.0 |  | mods目录 |
| 54 | `佚名 nsfw wysc` | 佚名 nsfw wysc | v0.1.0 |  | mods目录 |
| 55 | `会画画的Small_day sfw jrdx` | 会画画的Small_day sfw jrdx | 2.0 |  | mods目录 |
| 56 | `汐の雨い nsfw jrdx` | 汐の雨い nsfw jrdx | 1.0.0 |  | mods目录 |
| 57 | `anaertailin nsfw 1版 szslm(m)` | anaertailin nsfw 1版 szslm(m) | 0.0.1 |  | mods目录 |
| 58 | `anaertailin nsfw 1版 szslm(s)` | anaertailin nsfw 1版 szslm(s) | 0.0.1 |  | mods目录 |
| 59 | `anaertailin nsfw 1版 syslm(m)` | anaertailin nsfw 1版 syslm(m) | 0.0.1 |  | mods目录 |
| 60 | `anaertailin sfw 2版 syslm(m)` | anaertailin sfw 2版 syslm(m) | 0.0.1 |  | mods目录 |
| 61 | `anaertailin nsfw 1版 syslm(s)` | anaertailin nsfw 1版 syslm(s) | 0.0.1 |  | mods目录 |
| 62 | `anaertailin sfw 1版 syslm(s)` | anaertailin sfw 1版 syslm(s) | 0.0.1 |  | mods目录 |
| 63 | `Kiteseven nsfw csqzc` | Kiteseven nsfw csqzc | 0.0.1 |  | mods目录 |
| 64 | `Kiteseven sfw csqzc` | Kiteseven sfw csqzc | 0.0.1 |  | mods目录 |
| 65 | `anaertailin nsfw 无腿环衣领-无裙子 mrfdc` | anaertailin nsfw 无腿环衣领-无裙子 mrfdc | 1.0.0 |  | mods目录 |
| 66 | `anaertailin nsfw 无腿环衣领-有裙子 mrfdc` | anaertailin nsfw 无腿环衣领-有裙子 mrfdc | 1.0.0 |  | mods目录 |
| 67 | `anaertailin nsfw 有腿环衣领-无裙子 mrfdc` | anaertailin nsfw 有腿环衣领-无裙子 mrfdc | 1.0.0 |  | mods目录 |
| 68 | `anaertailin nsfw 有腿环衣领-有裙子 mrfdc` | anaertailin nsfw 有腿环衣领-有裙子 mrfdc | 1.0.0 |  | mods目录 |
| 69 | `anaertailin sfw mrfdc` | anaertailin sfw mrfdc | 1.0.0 |  | mods目录 |
| 70 | `锭_grayingot sfw pbjs` | 锭_grayingot sfw pbjs | 0.0.4 |  | mods目录 |
| 71 | `会画画的Small_day nsfw 人型 hjtjht` | 会画画的Small_day nsfw 人型 hjtjht | 2.0 |  | mods目录 |
| 72 | `会画画的Small_day sfw 人型 hjtjht` | 会画画的Small_day sfw 人型 hjtjht | 2.0 |  | mods目录 |
| 73 | `会画画的Small_day sfw 怪物型 hjtjht` | 会画画的Small_day sfw 怪物型 hjtjht | 2.0 |  | mods目录 |
| 74 | `锭_grayingot sfw lhyy` | 锭_grayingot sfw lhyy | 0.0.4 |  | mods目录 |
| 75 | `正无穷多边形 sfw 新版 lhsn` | 正无穷多边形 sfw 新版 lhsn | 1.1.1 |  | mods目录 |
| 76 | `正无穷多边形 sfw 旧版 lhsn` | 正无穷多边形 sfw 旧版 lhsn | 1.0.3 |  | mods目录 |
| 77 | `汐の雨い sfw lhsn` | 汐の雨い sfw lhsn | 1.0.0 |  | mods目录 |
| 78 | `1987的某一天 sfw lrss` | 1987的某一天 sfw lrss | v0.2.0 |  | mods目录 |
| 79 | `1987的某一天 sfw zfcrc` | 1987的某一天 sfw zfcrc | v0.2.0 |  | mods目录 |
| 80 | `佚名 nsfw zsem` | 佚名 nsfw zsem | 1.0.0 |  | mods目录 |
| 81 | `会画画的Small_day sfw sxjc` | 会画画的Small_day sfw sxjc | 2.0 |  | mods目录 |
| 82 | `1987的某一天 sfw lgg` | 1987的某一天 sfw lgg | v0.2.0 |  | mods目录 |
| 83 | `succubusIroncladHpWear` | 魅魔战士血量换装[两档] | 1.0.26 |  | mods目录 |
| 84 | `The ancient people were fully nurtured by nature (not yet completed)` | 先古全娘化（暂未完成） | 1.0.0 |  | workshop |
| 85 | `LoadOrderManager` | Load Order Manager / 模组加载顺序管理 | 0.4.0 | 0.107.1 | workshop |
| 86 | `BetterModMenu` | Better Mod Menu | 1.1.5 | 0.107.1 | workshop |
| 87 | `RegentFX` | 万象辉星[RegentFX] | 0.5.2 | 0.103.0 | workshop |
| 88 | `ShieldOnly` | More Ironclad Animations | 1.9.61-mp.5 | v0.107.1 | workshop |
| 89 | `MoreNecrobinderAnimations` | More Necrobinder Animations | 0.1.27 |  | workshop |
| 90 | `MoreDefectAnimations` | More Defect Animations | 0.17.3 |  | workshop |
| 91 | `OnlineExchange` | Online Exchange | 1.2.3 |  | workshop |
| 92 | `No color cards lewd full feminization complete version` | No color cards lewd full feminization complete version | 1.0 |  | workshop |
| 93 | `Kiteseven sfw yssl` | Kiteseven sfw yssl | 1.5.1 |  | mods目录 |
| 94 | `Pornographic beautification of all cards v2.1` | Pornographic beautification of all cards v2.1 | 2.1 |  | workshop |
| 95 | `BetterCallSpire` | BetterCallSpire | v1.0.0 |  | workshop |
| 96 | `CNRRegentCards` | CNRRegentCards | v5.26 |  | mods目录 |
| 97 | `卡图合集i站n版卡图2.0` | 卡图合集i站n版卡图2.0 | v1.0.0 |  | mods目录 |
| 98 | `N1.1` | N1.1 | v1.0.0 |  | mods目录 |
| 99 | `CNROtherCards` | CNROtherCards | v5.29 |  | mods目录 |
| 100 | `CNRDefectCards` | CNRDefectCards | v5.19 |  | mods目录 |
| 101 | `cutenecrobinder-nsfwv0.6` | cutenecrobinder-nsfwv0.6 | v1.0.0 |  | mods目录 |
| 102 | `AI_silent_NSFW_MOD` | AI_silent_NSFW_MOD | 1.0.3 |  | mods目录 |
| 103 | `silent` | 狐猎爆衣·Kaguya融合·全斗篷 | 0.3.0 |  | mods目录 |
| 104 | `汐の雨い sfw xsdb` | 汐の雨い sfw xsdb | 1.0.0 |  | mods目录 |
| 105 | `汐の雨い 半血爆衣 xsdb` | 汐の雨い 半血爆衣 xsdb | 1.0.0 |  | mods目录 |
| 106 | `汐の雨い sfw yss` | 汐の雨い sfw yss | 1.0.0 |  | mods目录 |
| 107 | `汐の雨い 半血爆衣 yss` | 汐の雨い 半血爆衣 yss | 1.0.0 |  | mods目录 |
| 108 | `汐の雨い sfw jlzck` | 汐の雨い sfw jlzck | 1.0.0 |  | mods目录 |
| 109 | `汐の雨い 半血爆衣 jlzck` | 汐の雨い 半血爆衣 jlzck | 1.0.0 |  | mods目录 |
| 110 | `汐の雨い sfw djyb` | 汐の雨い sfw djyb | 1.0.0 |  | mods目录 |
| 111 | `汐の雨い sfw mb` | 汐の雨い sfw mb | 1.0.0 |  | mods目录 |
| 112 | `汐の雨い sfw myhl` | 汐の雨い sfw myhl | 1.0.0 |  | mods目录 |
| 113 | `汐の雨い 半血爆衣 myhl` | 汐の雨い 半血爆衣 myhl | 1.0.0 |  | mods目录 |
| 114 | `汐の雨い sfw wggc` | 汐の雨い sfw wggc | 1.0.0 |  | mods目录 |
| 115 | `汐の雨い sfw xks` | 汐の雨い sfw xks | 1.0.0 |  | mods目录 |
| 116 | `汐の雨い 半血爆衣 xks` | 汐の雨い 半血爆衣 xks | 1.0.0 |  | mods目录 |
| 117 | `汐の雨い sfw dhx(hj&nsz)` | 汐の雨い sfw dhx(hj&nsz) | 1.0.0 |  | mods目录 |
| 118 | `汐の雨い 半血爆衣 dhx(hj&nsz)` | 汐の雨い 半血爆衣 dhx(hj&nsz) | 1.0.0 |  | mods目录 |
| 119 | `汐の雨い sfw wysc` | 汐の雨い sfw wysc | 1.0.0 |  | mods目录 |
| 120 | `汐の雨い sfw jrdx` | 汐の雨い sfw jrdx | 1.0.0 |  | mods目录 |
| 121 | `汐の雨い 半血爆衣  jrdx` | 汐の雨い 半血爆衣  jrdx | 1.0.0 |  | mods目录 |
| 122 | `汐の雨い sfw qtzd` | 汐の雨い sfw qtzd | 1.0.0 |  | mods目录 |
| 123 | `汐の雨い sfw csxjt&ghxjt` | 汐の雨い sfw csxjt&ghxjt | 1.0.0 |  | mods目录 |
| 124 | `汐の雨い 半血爆衣 csxjt&ghxjt` | 汐の雨い 半血爆衣 csxjt&ghxjt | 1.0.0 |  | mods目录 |
| 125 | `汐の雨い sfw sgjksg` | 汐の雨い sfw sgjksg | 1.0.0 |  | mods目录 |
| 126 | `汐の雨い 半血爆衣 sgjksg` | 汐の雨い 半血爆衣 sgjksg | 1.0.0 |  | mods目录 |
| 127 | `汐の雨い sfw hm` | 汐の雨い sfw hm | 1.0.0 |  | mods目录 |
| 128 | `汐の雨い 半血爆衣 hm` | 汐の雨い 半血爆衣 hm | 1.0.0 |  | mods目录 |
| 129 | `regentHpWear` | 储君皮肤 Mesugaki（含血量战损换装）[107] | 0.7.55 |  | mods目录 |
| 130 | `defectHpWear` | 机器人皮肤 MechaNeko（含血量战损换装）[107] | 0.7.65 |  | mods目录 |
| 131 | `CNRSilentCards` | CNRSilentCards | v5.29 |  | mods目录 |
| 132 | `RTRsMoeifyMod_cards` | RTRsMoeifyMod_cards | v0.2.0 |  | mods目录 |
| 133 | `CNRIroncladCards` | CNRIroncladCards | v5.29 |  | mods目录 |
| 134 | `CNRNecrobinderCards` | CNRNecrobindertCards | v6.27 |  | mods目录 |
| 135 | `CuteNecrobinder-Cards-Rework-nsfw` | CuteNecrobinder-Cards-Rework-nsfw | 0.0.1 |  | mods目录 |
| 136 | `NecroCardArtPortraits` | Necro Card Art | 0.2.0 |  | workshop |
| 137 | `SignatureLib` | SignatureLib | v1.0.0 |  | workshop |
| 138 | `vantomSlipperyWear` | 墨影幻灵·滑溜血量单向换装 | 1.2.1 |  | mods目录 |
| 139 | `anaertailin nsfw xks` | anaertailin nsfw xks | 0.0.1 |  | mods目录 |
| 140 | `anaertailin sfw xks` | anaertailin sfw xks | 0.0.1 |  | mods目录 |
| 141 | `Kiteseven nsfw 2改 csqzc` | Kiteseven nsfw 2改 csqzc | 0.0.1 |  | mods目录 |
| 142 | `RandomVision` | RandomVision | 0.2.0 |  | workshop |
| 143 | `OmniscientCrystalSphere` | Omniscient Crystal Sphere | v0.4.1 | 0.107.0 | workshop |
| 144 | `figure_Saya` | 沙耶之歌 | 2.2.0 | 0.107.1 | workshop |
| 145 | `intentgraph2` | Intent Graph | 1.6.0 | 0.107.1 | workshop |
| 146 | `RandomForeseer) (RandomForeseer` |  |  |  |  |
| 147 | `SkadaHelper` | 皮皮军师: SkadaHelper | 0.23.2 |  | workshop |
| 148 | `FullMapPreview` | 全地图预测(FullMapPreview) | 1.0.0 | 0.107.0 | workshop |
| 149 | `AutoModSubscriber` | Auto Mod Subscriber | 0.1.5 | 0.107.1 | workshop |
| 150 | `IzumiKonata` | Lucky Star — Izumi Konata | 0.1.9 | 0.107.1 | workshop |
| 151 | `MaidenSuccubus` | HibikiAmane | 0.1.0 | 0.113.0 | workshop |
| 152 | `MpLib` | MpLib | 0.0.5 | 0.111.0 | workshop |
| 153 | `LustTravel2` | LustTravel2 | 0.60.0 | 0.111.0 | workshop |
| 154 | `BaseLibCompatibilityHelper` | BaseLib Compatibility Helper | v0.0.0 | 0.107.0 | workshop |
| 155 | `BaseLib` | BaseLib | v3.4.8 | 0.107.1 | workshop |
| 156 | `QuickRestart` | Quick Restart | v1.0.1 | 0.107.0 | mods目录 |
| 157 | `HoldYourTurn` | HoldYourTurn | v0.3.0 | 0.107.0 | workshop |
| 158 | `MintySpire2` | Minty Spire 2 | v1.3.0 | 0.107.0 | workshop |
| 159 | `TaTaRim` | TaTaRim | 0.4.9 | 0.107.1 | workshop |
| 160 | `TaTaKaf` | TaTaKaf | v0.8.6 | 0.107.1 | workshop |
| 161 | `neowmerchant` | 商人娘化涅奥版 | 1.3.2 | 0.107.1 | mods目录 |
| 162 | `necrobinderHpWear` | 骨妹四档血量换装[fourform] | 1.0.70 |  | mods目录 |
| 163 | `JoanofArcIroncladHpwear` | 战士贞德 血量换装 | 0.3.16 |  | mods目录 |
| 164 | `ironcladHpWear` | 战士血量换装[107–111] | 1.0.85 |  | mods目录 |
| 165 | `Gurio.SkinChanger` | 皮肤切换器-Skin Changer | 1.0.31 | 0.107.1 | workshop |
| 166 | `MesugakiRegentCards` | 储君 Mesugaki 卡图 | 1.0.0 | 0.111.0 | workshop |
| 167 | `MoreSilentAnimations` | More Silent Animations | 0.1.36 | 0.107.1 | workshop |

设置中被禁用(未加载)的 Mod:`MFML`, `KitLib`, `Sts2SkinManager`
