using Godot;
using MegaCrit.Sts2.Core.Models;
using STS2SkinChanger.Core;

namespace STS2SkinChanger.Ui;

internal partial class AncientCompendiumScreen
{
    private OptionButton _eventRegionSelector = null!;
    private string? _eventRegion;
    private HashSet<string> _eventRegionMembers = new(StringComparer.OrdinalIgnoreCase);
    private bool _refreshingEventRegions;

    private static readonly IReadOnlyDictionary<string, (string Global, string Shared, string Other)> EventRegionNames =
        new Dictionary<string, (string, string, string)>
        {
            ["eng"] = ("All events", "Across regions", "Other regions"),
            ["zhs"] = ("全部事件", "跨地区", "其它地区"),
            ["zht"] = ("全部事件", "跨地區", "其他地區"),
            ["deu"] = ("Alle Ereignisse", "Regionsübergreifend", "Andere Regionen"),
            ["esp"] = ("Todos los eventos", "Varias regiones", "Otras regiones"),
            ["spa"] = ("Todos los eventos", "Varias regiones", "Otras regiones"),
            ["fra"] = ("Tous les événements", "Plusieurs régions", "Autres régions"),
            ["ita"] = ("Tutti gli eventi", "Più regioni", "Altre regioni"),
            ["jpn"] = ("すべてのイベント", "地域共通", "その他の地域"),
            ["kor"] = ("모든 이벤트", "공통 지역", "기타 지역"),
            ["pol"] = ("Wszystkie wydarzenia", "Wiele regionów", "Pozostałe regiony"),
            ["ptb"] = ("Todos os eventos", "Várias regiões", "Outras regiões"),
            ["rus"] = ("Все события", "Разные регионы", "Прочие регионы"),
            ["tha"] = ("เหตุการณ์ทั้งหมด", "หลายพื้นที่", "พื้นที่อื่น"),
            ["tur"] = ("Tüm olaylar", "Bölgeler arası", "Diğer bölgeler")
        };

    private void BuildEventRegionSelector(VBoxContainer sidebar)
    {
        _eventRegionSelector = new OptionButton
        {
            Name = "EventRegionSelector", Visible = false, FitToLongestItem = false,
            ClipText = true, Alignment = HorizontalAlignment.Center,
            CustomMinimumSize = new Vector2(0, 44), SizeFlagsHorizontal = SizeFlags.ExpandFill
        };
        ContextualSkinControls.ApplyGameTheme(_eventRegionSelector);
        sidebar.AddChild(_eventRegionSelector);
        _eventRegionSelector.ItemSelected += index =>
        {
            if (_refreshingEventRegions) return;
            _eventRegion = _eventRegionSelector.GetItemMetadata(checked((int)index)).AsString();
            _selectedOther = null;
            RefreshAncients();
        };
    }

    private static IEnumerable<string> EventsOf(ActModel act)
    {
        try
        {
            return act.AllEvents.Select(model => model.Id.Entry).ToArray();
        }
        catch (Exception exception)
        {
            ModLog.Warn($"读取地区 {act.Id.Entry} 的事件失败，已按空列表处理：" +
                        exception.GetBaseException().Message);
            return [];
        }
    }

    private void RefreshEventRegions()
    {
        _eventRegionSelector.Visible = _selectedCategory == OtherCategory.Events;
        // Event controls occupy the unused lower-left, not the native text/options column.
        _skinSelector.Position = _selectedCategory == OtherCategory.Events ? new Vector2(70, 940) : new Vector2(818, 826);
        if (_selectedCategory != OtherCategory.Events) { RefreshEventPriorityHeader(); return; }
        var acts = ActCatalog.All.ToArray();
        var groups = new Dictionary<string, string[]>(
            EventRegionPolicy.Group(EventCompendiumPreview.Events().Select(e => e.Id.Entry),
                acts.ToDictionary(a => a.Id.Entry, a => EventsOf(a)),
                ModelDb.AllSharedEvents.Select(e => e.Id.Entry)),
            StringComparer.OrdinalIgnoreCase);
        // Content-mod acts must be selectable even before any event skin of theirs is discovered.
        foreach (var act in acts)
        {
            groups.TryAdd(act.Id.Entry, []);
        }
        var names = EventRegionNames.GetValueOrDefault(ModLocalization.CurrentLanguage, EventRegionNames["eng"]);
        var titles = acts.ToDictionary(
            a => a.Id.Entry,
            a =>
            {
                try
                {
                    var title = a.Title.GetFormattedText();
                    return string.IsNullOrWhiteSpace(title) ? a.Id.Entry : title;
                }
                catch
                {
                    return a.Id.Entry;
                }
            });
        titles[EventRegionPolicy.Global] = names.Global;
        titles[EventRegionPolicy.Shared] = names.Shared;
        titles[EventRegionPolicy.Other] = names.Other;
        _refreshingEventRegions = true;
        try
        {
            _eventRegionSelector.Clear();
            if (_eventRegion == null || !groups.ContainsKey(_eventRegion)) _eventRegion = groups.Keys.FirstOrDefault();
            foreach (var (id, _) in groups)
            {
                var index = _eventRegionSelector.ItemCount;
                _eventRegionSelector.AddItem(titles[id]);
                _eventRegionSelector.SetItemMetadata(index, id);
                if (id == _eventRegion) _eventRegionSelector.Select(index);
            }
            _eventRegionMembers = (_eventRegion != null ? groups[_eventRegion] : [])
                .ToHashSet(StringComparer.OrdinalIgnoreCase);
        }
        finally { _refreshingEventRegions = false; }
        RefreshEventPriorityHeader();
    }
}