namespace STS2SkinChanger.Core;

internal enum BundleContentMode { MultiplePresets, ModPriority }

internal sealed record BundleModPriorityEntry(string OptionId, bool Enabled);

internal sealed class CharacterSkinBundle
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    internal string PresetKey => "__bundle_preset__:" + Id;
    public bool HideSources { get; set; } = true;
    public string Name { get; set; } = string.Empty;
    public string CharacterGroupId { get; set; } = string.Empty;
    public string CharacterOptionId { get; set; } = "__base__";
    public BundleContentMode CardMode { get; set; }
    public BundleContentMode MonsterMode { get; set; }
    public List<BundleModPriorityEntry> CardModPriority { get; set; } = [];
    public List<BundleModPriorityEntry> MonsterModPriority { get; set; } = [];
    public Dictionary<string, string> CardPresetNames { get; set; } =
        new(StringComparer.OrdinalIgnoreCase);
    public Dictionary<string, string> MonsterPresetNames { get; set; } =
        new(StringComparer.OrdinalIgnoreCase);
}

internal static class CharacterSkinBundlePolicy
{
    private const string SelectionOptionPrefix = "__skin_bundle__:";

    internal static string CreateSelectionOptionId(string name) =>
        SelectionOptionPrefix + Uri.EscapeDataString(name.Trim());

    internal static bool TryGetSelectionBundleName(string? optionId, out string name)
    {
        name = string.Empty;
        if (string.IsNullOrWhiteSpace(optionId) ||
            !optionId.StartsWith(SelectionOptionPrefix, StringComparison.Ordinal))
        {
            return false;
        }

        try
        {
            name = Uri.UnescapeDataString(optionId[SelectionOptionPrefix.Length..]).Trim();
            return name.Length > 0;
        }
        catch (UriFormatException)
        {
            name = string.Empty;
            return false;
        }
    }

    internal static string CreateSelectionDisplayName(string name) => "[P] " + name.Trim();

    internal static bool IsValidCharacterOptionReference(string? optionId) =>
        !string.IsNullOrWhiteSpace(optionId) && !TryGetSelectionBundleName(optionId, out _);

    internal static bool TryEnterApplication(
        string groupId,
        string bundleName,
        IReadOnlySet<string> activeApplications,
        out HashSet<string> nextApplications)
    {
        nextApplications = new HashSet<string>(activeApplications, StringComparer.OrdinalIgnoreCase);
        return nextApplications.Add(groupId.Trim() + "\n" + bundleName.Trim());
    }

    internal static bool ChangesOutsideRequestedGroups(
        IReadOnlyDictionary<string, string> original, IReadOnlyDictionary<string, string> staged,
        IEnumerable<string> protectedGroups, IReadOnlySet<string> requestedGroups) =>
        protectedGroups.Any(id => !requestedGroups.Contains(id) &&
            !string.Equals(original.GetValueOrDefault(id, "__base__"), staged.GetValueOrDefault(id, "__base__"),
                StringComparison.OrdinalIgnoreCase));

    internal static List<CharacterSkinBundle> Normalize(IEnumerable<CharacterSkinBundle>? bundles)
    {
        return (bundles ?? [])
            .Where(bundle => bundle != null &&
                             !string.IsNullOrWhiteSpace(bundle.Name) &&
                             !string.IsNullOrWhiteSpace(bundle.CharacterGroupId))
            .Select(bundle => new CharacterSkinBundle
            {
                Id = string.IsNullOrWhiteSpace(bundle.Id) ? Guid.NewGuid().ToString("N") : bundle.Id.Trim(),
                HideSources = bundle.HideSources,
                Name = bundle.Name.Trim(),
                CharacterGroupId = bundle.CharacterGroupId.Trim().ToLowerInvariant(),
                CharacterOptionId = string.IsNullOrWhiteSpace(bundle.CharacterOptionId)
                    ? "__base__"
                    : bundle.CharacterOptionId.Trim(),
                CardMode = NormalizeMode(bundle.CardMode),
                MonsterMode = NormalizeMode(bundle.MonsterMode),
                CardModPriority = NormalizePriority(bundle.CardModPriority),
                MonsterModPriority = NormalizePriority(bundle.MonsterModPriority),
                CardPresetNames = NormalizeReferences(bundle.CardPresetNames),
                MonsterPresetNames = NormalizeReferences(bundle.MonsterPresetNames)
            })
            .DistinctBy(
                bundle => bundle.CharacterGroupId + "\n" + bundle.Name,
                StringComparer.OrdinalIgnoreCase)
            .ToList();
    }

    internal static void RenamePresetReference(
        CharacterSkinBundle bundle,
        bool monsterPreset,
        string categoryId,
        string previousName,
        string newName)
    {
        var references = monsterPreset ? bundle.MonsterPresetNames : bundle.CardPresetNames;
        if (references.TryGetValue(categoryId, out var current) &&
            current.Equals(previousName, StringComparison.OrdinalIgnoreCase))
        {
            references[categoryId] = newName;
        }
    }

    internal static void RemovePresetReference(
        CharacterSkinBundle bundle,
        bool monsterPreset,
        string categoryId,
        string presetName)
    {
        var references = monsterPreset ? bundle.MonsterPresetNames : bundle.CardPresetNames;
        if (references.TryGetValue(categoryId, out var current) &&
            current.Equals(presetName, StringComparison.OrdinalIgnoreCase))
        {
            references[categoryId] = bundle.PresetKey;
        }
    }

    internal static CharacterSkinBundle Clone(CharacterSkinBundle bundle) =>
        new()
        {
            Id = bundle.Id,
            HideSources = bundle.HideSources,
            Name = bundle.Name,
            CharacterGroupId = bundle.CharacterGroupId,
            CharacterOptionId = bundle.CharacterOptionId,
            CardMode = NormalizeMode(bundle.CardMode),
            MonsterMode = NormalizeMode(bundle.MonsterMode),
            CardModPriority = NormalizePriority(bundle.CardModPriority),
            MonsterModPriority = NormalizePriority(bundle.MonsterModPriority),
            CardPresetNames = new Dictionary<string, string>(
                bundle.CardPresetNames, StringComparer.OrdinalIgnoreCase),
            MonsterPresetNames = new Dictionary<string, string>(
                bundle.MonsterPresetNames, StringComparer.OrdinalIgnoreCase)
        };

    private static BundleContentMode NormalizeMode(BundleContentMode mode) =>
        mode == BundleContentMode.ModPriority ? mode : BundleContentMode.MultiplePresets;

    internal static List<BundleModPriorityEntry> NormalizePriority(IEnumerable<BundleModPriorityEntry>? entries) =>
        (entries ?? []).Where(entry => entry != null && !string.IsNullOrWhiteSpace(entry.OptionId))
            .Select(entry => entry with { OptionId = entry.OptionId.Trim() })
            .DistinctBy(entry => entry.OptionId, StringComparer.OrdinalIgnoreCase).ToList();

    internal static List<BundleModPriorityEntry> CompletePriority(
        IEnumerable<BundleModPriorityEntry>? stored, IEnumerable<string> available)
    {
        var entries = NormalizePriority(stored);
        var known = entries.Select(entry => entry.OptionId).ToHashSet(StringComparer.OrdinalIgnoreCase);
        foreach (var id in available)
            if (known.Add(id)) entries.Add(new(id, Enabled: false));
        return entries;
    }

    // Explicitly include disabled category sources: the normal priority readers otherwise
    // auto-enable missing entries, which would leak the previous/global selection into a run.
    internal static List<BundleModPriorityEntry> ProjectPriority(
        IReadOnlyList<BundleModPriorityEntry> entries, IEnumerable<string> categorySources)
    {
        var ids = categorySources.ToHashSet(StringComparer.OrdinalIgnoreCase);
        var result = entries.Where(entry => ids.Contains(entry.OptionId)).ToList();
        var included = result.Select(entry => entry.OptionId).ToHashSet(StringComparer.OrdinalIgnoreCase);
        result.AddRange(ids.Where(id => !included.Contains(id)).Select(id => new BundleModPriorityEntry(id, false)));
        return result;
    }

    private static Dictionary<string, string> NormalizeReferences(
        IReadOnlyDictionary<string, string>? references) =>
        (references ?? new Dictionary<string, string>())
            .Where(pair => !string.IsNullOrWhiteSpace(pair.Key) &&
                           !string.IsNullOrWhiteSpace(pair.Value))
            .DistinctBy(pair => pair.Key.Trim(), StringComparer.OrdinalIgnoreCase)
            .ToDictionary(
                pair => pair.Key.Trim().ToLowerInvariant(),
                pair => pair.Value.Trim(),
                StringComparer.OrdinalIgnoreCase);
}

// Persistence is the final step. A failed preparation never touches resources; a failed
// refresh or save restores the original configuration before rebuilding its resources.
internal static class StagedConfigurationTransaction
{
    internal static Exception? Run<T>(
        T original, T staged, Action<T> setCurrent, Action prepare,
        Action refresh, Action<T> persist, Action restoreResources)
    {
        var refreshStarted = false;
        setCurrent(staged);
        try
        {
            prepare();
            refreshStarted = true;
            refresh();
            persist(staged);
            return null;
        }
        catch (Exception error)
        {
            setCurrent(original);
            if (refreshStarted)
            {
                try
                {
                    restoreResources();
                }
                catch (Exception restoreError)
                {
                    return new AggregateException(error, restoreError);
                }
            }
            return error;
        }
    }
}
