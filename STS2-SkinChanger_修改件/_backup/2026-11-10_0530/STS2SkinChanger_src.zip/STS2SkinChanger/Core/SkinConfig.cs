using System.Text.Json;

namespace STS2SkinChanger.Core;

internal sealed record CardSkinPriorityEntry(
    string OptionId,
    bool Enabled);

internal sealed class CardSkinPreset
{
    public bool AllOriginal { get; set; }
    public string Name { get; set; } = string.Empty;

    // Empty for presets written by versions before presets were scoped to a card category.
    // SkinService migrates those entries once the card catalogue is available.
    public string? CategoryId { get; set; }

    public Dictionary<string, List<CardSkinPriorityEntry>> CardSkinPriorities { get; set; } =
        new(StringComparer.OrdinalIgnoreCase);

    public Dictionary<string, string> Selections { get; set; } =
        new(StringComparer.OrdinalIgnoreCase);

    internal CardSkinPreset Clone() => new()
    {
        Name = Name, CategoryId = CategoryId, AllOriginal = AllOriginal,
        CardSkinPriorities = CardSkinPriorities.ToDictionary(p => p.Key, p => p.Value.ToList(), StringComparer.OrdinalIgnoreCase),
        Selections = new(Selections, StringComparer.OrdinalIgnoreCase)
    };
}

internal sealed record MonsterSkinPriorityEntry(
    string OptionId,
    bool Enabled);

internal sealed class MonsterSkinPreset
{
    public bool AllOriginal { get; set; }
    public string Name { get; set; } = string.Empty;
    public string CategoryId { get; set; } = string.Empty;
    public List<MonsterSkinPriorityEntry> Priority { get; set; } = [];
    public Dictionary<string, string> Selections { get; set; } =
        new(StringComparer.OrdinalIgnoreCase);
    public List<string> FollowingGroupIds { get; set; } = [];

    internal MonsterSkinPreset Clone() => new()
    {
        Name = Name, CategoryId = CategoryId, AllOriginal = AllOriginal,
        Priority = Priority.ToList(), Selections = new(Selections, StringComparer.OrdinalIgnoreCase),
        FollowingGroupIds = FollowingGroupIds.ToList()
    };
}

internal sealed class SkinConfig
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        PropertyNameCaseInsensitive = true
    };

    public Dictionary<string, string> Selections { get; set; } = new(StringComparer.OrdinalIgnoreCase);

    // A next-run instruction, not a provider ID. Keep the actual loaded source separate.
    public List<string> RandomCharacterSkinGroups { get; set; } = [];

    public Dictionary<string, List<string>> RandomCharacterSkinExclusions { get; set; } =
        new(StringComparer.OrdinalIgnoreCase);

    public List<SlotVisibilitySelection> SlotVisibilitySelections { get; set; } = [];

    // Legacy migration input only. Current versions treat icon packs as ordinary character skins
    // and convert an explicit old icon choice into a saved composition during initialization.
    public Dictionary<string, string> CharacterIconSelections { get; set; } =
        new(StringComparer.OrdinalIgnoreCase);

    public List<CharacterSkinComposition> CharacterSkinCompositions { get; set; } = [];

    public List<CharacterSkinBundle> CharacterSkinBundles { get; set; } = [];

    public Dictionary<string, string> ActiveCharacterSkinBundles { get; set; } =
        new(StringComparer.OrdinalIgnoreCase);

    public List<string> VisualProviderPriority { get; set; } = [];

    public int VisualSelectionDefaultsVersion { get; set; }

    /// <summary>
    /// One-time migration that lets a style/UI package's overridden parts stay the default of their
    /// group, so recognising them does not switch off what the player already sees.
    /// </summary>
    public int BaselinePartTakeoverVersion { get; set; }

    /// <summary>
    /// 玩家是否已经把"随从（奥斯提）外观"当成独立选项手动选过。
    /// 一旦为 true，就不再按主人皮肤自动推导随从外观，两边彻底互不影响；
    /// 为 false 时保留旧行为（随从跟随主人皮肤），老存档升级后不会突然变样。
    /// </summary>
    public bool CompanionSelectionDecoupled { get; set; }

    /// <summary>
    /// 选中的「独立奥斯提 Mod」皮肤 id（例如 OstyDefectImpostor 的
    /// <c>OstyDefectImpostor.ground_defect</c>）；为空表示不用它的皮肤。
    /// 与皮肤目录里的 osty 选择互斥：选它时 osty 组回到游戏原版，由那个 Mod 自己渲染。
    /// </summary>
    public string? CompanionImpostorSkinId { get; set; }

    /// <summary>随从外观是否处于“随机皮肤”状态（与角色下拉的随机语义一致）。</summary>
    public bool CompanionRandomEnabled { get; set; }

    public Dictionary<string, List<CardSkinPriorityEntry>> CardSkinPriorities { get; set; } =
        new(StringComparer.OrdinalIgnoreCase);

    public int CardPriorityDefaultsVersion { get; set; }

    public List<CardSkinPreset> CardSkinPresets { get; set; } = [];
    public int CardPresetMigrationRepairVersion { get; set; }
    public List<CardSkinPreset> ArchivedLegacyCardSkinPresets { get; set; } = [];

    // Active preset is now tracked independently for each card catalogue category. Keep the
    // single value below so old configuration files can be migrated without losing the active
    // preset name.
    public Dictionary<string, string> ActiveCardSkinPresets { get; set; } =
        new(StringComparer.OrdinalIgnoreCase);

    public string? ActiveCardSkinPreset { get; set; }

    public Dictionary<string, List<MonsterSkinPriorityEntry>> MonsterSkinPriorities { get; set; } =
        new(StringComparer.OrdinalIgnoreCase);

    public List<MonsterSkinPreset> MonsterSkinPresets { get; set; } = [];

    public Dictionary<string, string> ActiveMonsterSkinPresets { get; set; } =
        new(StringComparer.OrdinalIgnoreCase);

    public Dictionary<string, List<string>> MonsterSkinCategoryGroups { get; set; } =
        new(StringComparer.OrdinalIgnoreCase);

    // Legacy migration state from the short-lived region master switch implementation.
    public List<string> EnabledMonsterSkinPriorityCategories { get; set; } = [];

    public List<string> MonsterGroupsFollowingCategory { get; set; } = [];

    public List<string> MonsterGroupsWithManualSelection { get; set; } = [];

    public int MonsterPriorityDefaultsVersion { get; set; }

    public EventSkinPrioritySettings EventSkinPriorities { get; set; } = new();

    /// <summary>
    /// Battle background per act: act id → option id. A missing entry keeps whatever the active
    /// providers (for example a monster pack's own act/encounter backgrounds) present.
    /// </summary>
    public Dictionary<string, string> BackgroundSelections { get; set; } =
        new(StringComparer.OrdinalIgnoreCase);

    public Dictionary<string, Dictionary<string, float>> MonsterScales { get; set; } =
        new(StringComparer.OrdinalIgnoreCase);

    public Dictionary<string, Dictionary<string, CharacterCombatTransform>> CharacterCombatTransforms { get; set; } =
        new(StringComparer.OrdinalIgnoreCase);

    public bool SuppressLoadOrderWarning { get; set; }

    // Legacy state retained so the first run after upgrading can still detect a transition from a
    // previously safe order. New versions only require Skin Changer to precede every skin provider.
    public bool? LastKnownFirstInLoadOrder { get; set; }

    public bool? LastKnownBeforeAllSkinMods { get; set; }

    // Snapshot of the skin-provider order (including SkinChanger) from the last completed
    // load-order check. Null means no snapshot yet (fresh install or pre-1.0.19.17 config).
    public List<string>? LastKnownSkinProviderOrder { get; set; }

    // F35：已经处理过的皮肤提供者 ID。再次出现在本 Mod 上方时视为玩家手动排序，自动排序
    // 不再把它们压回，也不提醒重启；首次自动排序会把本次移动的提供者写入这里作为种子。
    public List<string> RespectedLoadOrderProviders { get; set; } = [];

    public bool MultiplayerSkinSyncEnabled { get; set; } = true;

    // 0=队友只显示原版，1=只显示双方都有的皮肤，2=队友显示我用的皮肤。见 MultiplayerSkinMode。
    public int MultiplayerSkinMode { get; set; } = -1;

    public bool LoadOtherPlayersCustomSkins { get; set; } = true;
    public EventSkinPrioritySettings AncientSkinPriorities { get; set; } = new();

    public bool ShowInRunAppearanceEntry { get; set; } = true;

    public bool ShowInRunBackgroundEntry { get; set; } = true;

    public bool CharacterSelectorTopRight { get; set; }

    public float? CharacterSkinSelectorX { get; set; }

    public float? CharacterSkinSelectorY { get; set; }

    public float? CharacterSkinMergeX { get; set; }

    public float? CharacterSkinMergeY { get; set; }

    public float? CharacterSkinBundleX { get; set; }

    public float? CharacterSkinBundleY { get; set; }

    public float? CharacterModelPreviewX { get; set; }

    public float? CharacterModelPreviewY { get; set; }

    public bool CharacterModelPreviewDocked { get; set; }

    public float? OstyModelPreviewX { get; set; }

    public float? OstyModelPreviewY { get; set; }

    public bool OstyModelPreviewDocked { get; set; }

    public float? IndividualCardSkinSelectorX { get; set; }

    public float? IndividualCardSkinSelectorY { get; set; }

    // Copy the mutable settings touched by bundle preparation/overlay normalization. Other
    // fields are deliberately retained without deserializing/migrating unrelated settings.
    internal SkinConfig CloneForBundleTransaction()
    {
        var copy = (SkinConfig)MemberwiseClone();
        copy.Selections = new(Selections, StringComparer.OrdinalIgnoreCase);
        copy.RandomCharacterSkinGroups = RandomCharacterSkinGroups.ToList();
        copy.CopyRandomCharacterSkinExclusionsFrom(this);
        copy.SlotVisibilitySelections = SlotVisibilitySelections
            .Select(state => state with { SourceSlots = state.SourceSlots.ToArray() }).ToList();
        copy.VisualProviderPriority = VisualProviderPriority.ToList();
        copy.CharacterSkinBundles = CharacterSkinBundles.Select(CharacterSkinBundlePolicy.Clone).ToList();
        copy.ActiveCharacterSkinBundles = new(ActiveCharacterSkinBundles, StringComparer.OrdinalIgnoreCase);
        copy.CardSkinPriorities = CardSkinPriorities.ToDictionary(
            pair => pair.Key, pair => pair.Value.ToList(), StringComparer.OrdinalIgnoreCase);
        copy.ActiveCardSkinPresets = new(ActiveCardSkinPresets, StringComparer.OrdinalIgnoreCase);
        copy.CardSkinPresets = CardSkinPresets.Select(preset => preset.Clone()).ToList();
        copy.ArchivedLegacyCardSkinPresets = ArchivedLegacyCardSkinPresets.Select(preset => preset.Clone()).ToList();
        copy.MonsterSkinPresets = MonsterSkinPresets.Select(preset => preset.Clone()).ToList();
        copy.MonsterSkinPriorities = MonsterSkinPriorities.ToDictionary(
            pair => pair.Key, pair => pair.Value.ToList(), StringComparer.OrdinalIgnoreCase);
        copy.ActiveMonsterSkinPresets = new(ActiveMonsterSkinPresets, StringComparer.OrdinalIgnoreCase);
        copy.MonsterSkinCategoryGroups = MonsterSkinCategoryGroups.ToDictionary(
            pair => pair.Key, pair => pair.Value.ToList(), StringComparer.OrdinalIgnoreCase);
        copy.EnabledMonsterSkinPriorityCategories = EnabledMonsterSkinPriorityCategories.ToList();
        copy.MonsterGroupsFollowingCategory = MonsterGroupsFollowingCategory.ToList();
        copy.MonsterGroupsWithManualSelection = MonsterGroupsWithManualSelection.ToList();
        copy.EventSkinPriorities = EventSkinPriorities.Clone();
        copy.AncientSkinPriorities = AncientSkinPriorities.Clone();
        return copy;
    }

    internal void CopyRandomCharacterSkinExclusionsFrom(SkinConfig source) =>
        RandomCharacterSkinExclusions = source.RandomCharacterSkinExclusions.ToDictionary(
            pair => pair.Key, pair => pair.Value.ToList(), StringComparer.OrdinalIgnoreCase);

    public static SkinConfig Load(string path)
    {
        var backupPath = path + ".bak";
        try
        {
            if (File.Exists(path))
            {
                return Deserialize(File.ReadAllText(path));
            }
        }
        catch (Exception exception)
        {
            ModLog.Warn($"读取皮肤配置失败，将尝试备份：{exception.Message}");
        }

        try
        {
            if (File.Exists(backupPath))
            {
                var recovered = Deserialize(File.ReadAllText(backupPath));
                ModLog.Warn("已从 skin_changer.json.bak 恢复皮肤选择设置。");
                return recovered;
            }
        }
        catch (Exception exception)
        {
            ModLog.Warn($"读取皮肤配置备份失败，将使用默认配置：{exception.Message}");
        }

        return new SkinConfig();
    }

    public void Save(string path)
    {
        Directory.CreateDirectory(System.IO.Path.GetDirectoryName(path)!);
        var temporaryPath = path + ".tmp";
        using (var stream = new FileStream(temporaryPath, FileMode.Create, FileAccess.Write, FileShare.None))
        {
            JsonSerializer.Serialize(stream, this, JsonOptions);
            // 先落盘再原子替换，避免崩溃留下空/半截的正式配置。
            stream.Flush(flushToDisk: true);
        }

        File.Move(temporaryPath, path, overwrite: true);
        try
        {
            File.Copy(path, path + ".bak", overwrite: true);
        }
        catch (Exception exception)
        {
            // 主配置已经安全落盘；备份失败不应让调用方回滚内存中的成功选择。
            ModLog.Warn("更新皮肤配置备份失败：" + exception.Message);
        }
    }

    private static SkinConfig Deserialize(string json)
    {
        var config = JsonSerializer.Deserialize<SkinConfig>(json, JsonOptions) ?? new SkinConfig();
        config.EventSkinPriorities ??= new();
        config.EventSkinPriorities.Normalize();
        config.AncientSkinPriorities ??= new();
        // 先古组 ID（ModelDb.AllAncients）不带 event: 前缀；按事件前缀过滤会把先古的地区组/手动组
        // 在每次加载时清空，重启后“跟随分类优先级”被 Register 迁移悄悄改回手动固定。
        config.AncientSkinPriorities.Normalize(_ => true);
        config.RandomCharacterSkinGroups = (config.RandomCharacterSkinGroups ?? [])
            .Where(id => !string.IsNullOrWhiteSpace(id)).Select(id => id.Trim())
            .Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        // Keep missing skin IDs, so unsubscribing temporarily does not erase preferences.
        config.RandomCharacterSkinExclusions = (config.RandomCharacterSkinExclusions ?? [])
            .Where(pair => !string.IsNullOrWhiteSpace(pair.Key))
            .GroupBy(pair => pair.Key.Trim(), StringComparer.OrdinalIgnoreCase)
            .ToDictionary(group => group.Key, group => group.SelectMany(pair => pair.Value ?? [])
                .Where(id => !string.IsNullOrWhiteSpace(id)).Select(id => id.Trim())
                .Where(RandomCharacterSkinPolicy.IsCandidate)
                .Distinct(StringComparer.OrdinalIgnoreCase).ToList(), StringComparer.OrdinalIgnoreCase);
        config.Selections ??= new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        config.Selections = new Dictionary<string, string>(
            config.Selections,
            StringComparer.OrdinalIgnoreCase);
        config.BackgroundSelections ??=
            new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        config.BackgroundSelections = config.BackgroundSelections
            .Where(pair => !string.IsNullOrWhiteSpace(pair.Key) &&
                           !string.IsNullOrWhiteSpace(pair.Value))
            .ToDictionary(
                pair => pair.Key.Trim().ToLowerInvariant(),
                pair => pair.Value.Trim(),
                StringComparer.OrdinalIgnoreCase);
        config.CharacterIconSelections ??=
            new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        config.CharacterIconSelections = config.CharacterIconSelections
            .Where(pair => !string.IsNullOrWhiteSpace(pair.Key) &&
                           !string.IsNullOrWhiteSpace(pair.Value))
            .ToDictionary(
                pair => pair.Key,
                pair => pair.Value,
                StringComparer.OrdinalIgnoreCase);
        config.CharacterSkinCompositions = CharacterSkinCompositionPolicy.Normalize(
            config.CharacterSkinCompositions);
        config.SlotVisibilitySelections = SlotVisibilityPolicy.Normalize(config.SlotVisibilitySelections);
        config.CharacterSkinBundles = CharacterSkinBundlePolicy.Normalize(
            config.CharacterSkinBundles);
        config.ActiveCharacterSkinBundles ??=
            new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        config.ActiveCharacterSkinBundles = config.ActiveCharacterSkinBundles
            .Where(pair => !string.IsNullOrWhiteSpace(pair.Key) &&
                           !string.IsNullOrWhiteSpace(pair.Value) &&
                           config.CharacterSkinBundles.Any(bundle =>
                               bundle.CharacterGroupId.Equals(
                                   pair.Key, StringComparison.OrdinalIgnoreCase) &&
                               bundle.Name.Equals(pair.Value, StringComparison.OrdinalIgnoreCase)))
            .ToDictionary(
                pair => pair.Key.Trim().ToLowerInvariant(),
                pair => pair.Value.Trim(),
                StringComparer.OrdinalIgnoreCase);
        config.VisualProviderPriority ??= [];
        config.VisualProviderPriority = config.VisualProviderPriority
            .Where(providerId => !string.IsNullOrWhiteSpace(providerId))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
        config.CardSkinPriorities ??=
            new Dictionary<string, List<CardSkinPriorityEntry>>(StringComparer.OrdinalIgnoreCase);
        config.CardSkinPriorities = config.CardSkinPriorities.ToDictionary(
            pair => pair.Key,
            pair => (pair.Value ?? [])
                .Where(entry => entry != null && !string.IsNullOrWhiteSpace(entry.OptionId))
                .ToList(),
            StringComparer.OrdinalIgnoreCase);
        config.CardSkinPresets ??= [];
        config.ArchivedLegacyCardSkinPresets ??= [];
        config.CardSkinPresets = config.CardSkinPresets
            .Where(preset => preset != null && !string.IsNullOrWhiteSpace(preset.Name))
            .Select(preset =>
            {
                preset.Name = preset.Name.Trim();
                preset.CategoryId = string.IsNullOrWhiteSpace(preset.CategoryId)
                    ? null
                    : preset.CategoryId.Trim().ToLowerInvariant();
                preset.CardSkinPriorities ??=
                    new Dictionary<string, List<CardSkinPriorityEntry>>(StringComparer.OrdinalIgnoreCase);
                preset.CardSkinPriorities = preset.CardSkinPriorities.ToDictionary(
                    pair => pair.Key,
                    pair => (pair.Value ?? [])
                        .Where(entry => entry != null && !string.IsNullOrWhiteSpace(entry.OptionId))
                        .ToList(),
                    StringComparer.OrdinalIgnoreCase);
                preset.Selections ??=
                    new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                preset.Selections = preset.Selections
                    .Where(pair => pair.Key.StartsWith("cards:", StringComparison.OrdinalIgnoreCase) &&
                                   !string.IsNullOrWhiteSpace(pair.Value))
                    .ToDictionary(
                        pair => pair.Key,
                        pair => pair.Value,
                        StringComparer.OrdinalIgnoreCase);
                return preset;
            })
            .DistinctBy(
                preset => (preset.CategoryId ?? string.Empty) + "\n" + preset.Name,
                StringComparer.OrdinalIgnoreCase)
            .ToList();
        config.ActiveCardSkinPresets ??=
            new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        config.ActiveCardSkinPresets = config.ActiveCardSkinPresets
            .Where(pair => !string.IsNullOrWhiteSpace(pair.Key) &&
                           !string.IsNullOrWhiteSpace(pair.Value) &&
                           config.CardSkinPresets.Any(preset =>
                               preset.CategoryId?.Equals(
                                   pair.Key,
                                   StringComparison.OrdinalIgnoreCase) == true &&
                               preset.Name.Equals(
                                   pair.Value,
                                   StringComparison.OrdinalIgnoreCase)))
            .ToDictionary(
                pair => pair.Key.Trim().ToLowerInvariant(),
                pair => pair.Value.Trim(),
                StringComparer.OrdinalIgnoreCase);
        config.ActiveCardSkinPreset = config.CardSkinPresets.Any(preset =>
            preset.Name.Equals(config.ActiveCardSkinPreset, StringComparison.OrdinalIgnoreCase))
                ? config.CardSkinPresets.First(preset =>
                    preset.Name.Equals(config.ActiveCardSkinPreset, StringComparison.OrdinalIgnoreCase)).Name
                : null;
        config.MonsterSkinPriorities ??=
            new Dictionary<string, List<MonsterSkinPriorityEntry>>(StringComparer.OrdinalIgnoreCase);
        config.MonsterSkinPriorities = config.MonsterSkinPriorities.ToDictionary(
            pair => pair.Key,
            pair => (pair.Value ?? [])
                .Where(entry => entry != null && !string.IsNullOrWhiteSpace(entry.OptionId))
                .ToList(),
            StringComparer.OrdinalIgnoreCase);
        config.MonsterSkinPresets ??= [];
        config.MonsterSkinPresets = config.MonsterSkinPresets
            .Where(preset => preset != null &&
                             !string.IsNullOrWhiteSpace(preset.Name) &&
                             !string.IsNullOrWhiteSpace(preset.CategoryId))
            .Select(preset =>
            {
                preset.Name = preset.Name.Trim();
                preset.CategoryId = preset.CategoryId.Trim().ToLowerInvariant();
                preset.Priority = (preset.Priority ?? [])
                    .Where(entry => entry != null && !string.IsNullOrWhiteSpace(entry.OptionId))
                    .DistinctBy(entry => entry.OptionId, StringComparer.OrdinalIgnoreCase)
                    .ToList();
                preset.Selections = new Dictionary<string, string>(
                    (preset.Selections ?? new Dictionary<string, string>())
                    .Where(pair => !string.IsNullOrWhiteSpace(pair.Key) &&
                                   !string.IsNullOrWhiteSpace(pair.Value))
                    .ToDictionary(pair => pair.Key, pair => pair.Value),
                    StringComparer.OrdinalIgnoreCase);
                preset.FollowingGroupIds = (preset.FollowingGroupIds ?? [])
                    .Where(groupId => !string.IsNullOrWhiteSpace(groupId))
                    .Distinct(StringComparer.OrdinalIgnoreCase)
                    .ToList();
                return preset;
            })
            .DistinctBy(
                preset => preset.CategoryId + "\n" + preset.Name,
                StringComparer.OrdinalIgnoreCase)
            .ToList();
        config.ActiveMonsterSkinPresets ??=
            new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        config.ActiveMonsterSkinPresets = config.ActiveMonsterSkinPresets
            .Where(pair => !string.IsNullOrWhiteSpace(pair.Key) &&
                           !string.IsNullOrWhiteSpace(pair.Value) &&
                           config.MonsterSkinPresets.Any(preset =>
                preset.CategoryId.Equals(pair.Key, StringComparison.OrdinalIgnoreCase) &&
                preset.Name.Equals(pair.Value, StringComparison.OrdinalIgnoreCase)))
            .ToDictionary(
                pair => pair.Key.Trim().ToLowerInvariant(),
                pair => pair.Value.Trim(),
                StringComparer.OrdinalIgnoreCase);
        config.MonsterSkinCategoryGroups ??=
            new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);
        config.MonsterSkinCategoryGroups = config.MonsterSkinCategoryGroups.ToDictionary(
            pair => pair.Key,
            pair => (pair.Value ?? [])
                .Where(groupId => !string.IsNullOrWhiteSpace(groupId))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList(),
            StringComparer.OrdinalIgnoreCase);
        config.EnabledMonsterSkinPriorityCategories ??= [];
        config.EnabledMonsterSkinPriorityCategories = config.EnabledMonsterSkinPriorityCategories
            .Where(categoryId => !string.IsNullOrWhiteSpace(categoryId))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
        config.MonsterGroupsFollowingCategory ??= [];
        config.MonsterGroupsFollowingCategory = config.MonsterGroupsFollowingCategory
            .Where(groupId => !string.IsNullOrWhiteSpace(groupId))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
        config.MonsterGroupsWithManualSelection ??= [];
        config.MonsterGroupsWithManualSelection = config.MonsterGroupsWithManualSelection
            .Where(groupId => !string.IsNullOrWhiteSpace(groupId))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
        config.MonsterScales ??=
            new Dictionary<string, Dictionary<string, float>>(StringComparer.OrdinalIgnoreCase);
        config.MonsterScales = config.MonsterScales.ToDictionary(
            pair => pair.Key,
            pair => new Dictionary<string, float>(
                pair.Value ?? new Dictionary<string, float>(),
                StringComparer.OrdinalIgnoreCase),
            StringComparer.OrdinalIgnoreCase);
        config.CharacterCombatTransforms ??=
            new Dictionary<string, Dictionary<string, CharacterCombatTransform>>(
                StringComparer.OrdinalIgnoreCase);
        config.CharacterCombatTransforms = config.CharacterCombatTransforms.ToDictionary(
            pair => pair.Key,
            pair => new Dictionary<string, CharacterCombatTransform>(
                (pair.Value ?? new Dictionary<string, CharacterCombatTransform>())
                .Where(option => option.Value != null)
                .ToDictionary(option => option.Key, option => option.Value),
                StringComparer.OrdinalIgnoreCase),
            StringComparer.OrdinalIgnoreCase);
        return config;
    }

    public string GetSelection(string groupId) =>
        Selections.GetValueOrDefault(groupId, Catalog.SkinCatalog.BaseOptionId);

}
