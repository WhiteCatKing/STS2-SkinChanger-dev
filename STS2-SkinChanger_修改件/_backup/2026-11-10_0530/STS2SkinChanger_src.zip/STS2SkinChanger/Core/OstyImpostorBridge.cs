using System.Reflection;
using Godot;

namespace STS2SkinChanger.Core;

/// <summary>
/// 「让鸡煲撑在地上假装自己是奥斯提」(OstyDefectImpostor) 的奥斯提皮肤桥。
///
/// 它自带一套奥斯提换肤（<c>OstySkinRegistry</c>：原版 / 撑在地上的鸡煲），并把
/// 奥斯提呈现改成自己的自建 SpineSprite。皮肤切换器现在把奥斯提当成一个独立选择项，
/// 所以这里只做两件事：
///   1. 把它的可选皮肤作为额外条目提供给「奥斯提下拉」；
///   2. 玩家选到它的皮肤时，通过反射调用它的 <c>OstySkinSelection.Apply(id)</c> 切换，
///      选到别的（皮肤自带的）奥斯提皮肤时先切回它的「原版」，把位子让出来。
/// 全部走反射：没装这个 Mod 时字符串对不上，整段自动跳过。
/// </summary>
internal static class OstyImpostorBridge
{
    /// <summary>下拉选项 id 前缀，用来和皮肤目录里的选项区分。</summary>
    internal const string OptionPrefix = "impostor:";

    private const string AssemblyName = "OstyDefectImpostor";
    internal const string VanillaSkinId = "vanilla.osty";

    private static bool _resolved;
    private static Type? _selectionType;
    private static System.Reflection.Assembly? _assembly;
    private static bool _hooked;
    private static int _echoDepth;
    private static readonly List<(string Id, string Name)> Found = [];

    /// <summary>我们自己调用它的 Apply 时不回灌到自己的下拉（避免把它刚切好的皮肤又改回去）。</summary>
    internal static bool EchoSuppressed => _echoDepth > 0;

    internal static void Reset()
    {
        _resolved = false;
        _selectionType = null;
        _hooked = false;
        _echoDepth = 0;
        Found.Clear();
    }

    internal static string CreateOptionId(string skinId) => OptionPrefix + skinId;

    internal static bool TryParseOption(string optionId, out string skinId)
    {
        skinId = string.Empty;
        if (!optionId.StartsWith(OptionPrefix, StringComparison.OrdinalIgnoreCase))
        {
            return false;
        }

        skinId = optionId[OptionPrefix.Length..];
        return skinId.Length > 0;
    }

    internal static string GetOptionName(string optionId) =>
        TryParseOption(optionId, out var skinId) ? NameOf(skinId) : optionId;

    internal static bool IsImpostorOption(string optionId) =>
        TryParseOption(optionId, out _);

    /// <summary>它提供的奥斯提皮肤（不含"原版"，原版由本 Mod 自己的"游戏原版"条目表示）。</summary>
    internal static IReadOnlyList<(string Id, string Name)> Options
    {
        get
        {
            Resolve();
            return Found;
        }
    }

    private static void Resolve()
    {
        if (_resolved)
        {
            return;
        }

        _resolved = true;
        try
        {
            var assembly = AppDomain.CurrentDomain.GetAssemblies().FirstOrDefault(candidate =>
                string.Equals(candidate.GetName().Name, AssemblyName, StringComparison.OrdinalIgnoreCase));
            if (assembly == null)
            {
                return;
            }

            _selectionType = assembly.GetType("OstyDefectImpostor.OstySkinSelection", throwOnError: false);
            _assembly = assembly;
            var registryType = assembly.GetType("OstyDefectImpostor.OstySkinRegistry", throwOnError: false);
            if (registryType?.GetProperty("All", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic)
                    ?.GetValue(null) is System.Collections.IEnumerable items)
            {
                foreach (var item in items)
                {
                    if (item == null)
                    {
                        continue;
                    }

                    var type = item.GetType();
                    var id = type.GetProperty("Id", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
                        ?.GetValue(item) as string;
                    var name = type.GetProperty("Name", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
                        ?.GetValue(item) as string;
                    if (string.IsNullOrEmpty(id) ||
                        id.Equals(VanillaSkinId, StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }

                    Found.Add((id, string.IsNullOrEmpty(name) ? id : name));
                }
            }

            ModLog.Info($"[奥斯提] 已接入 {AssemblyName} 的 {Found.Count} 个独立奥斯提皮肤。");
        }
        catch (Exception exception)
        {
            ModLog.Warn($"[奥斯提] 读取 {AssemblyName} 皮肤列表失败：{exception.GetBaseException().Message}");
        }
    }

    private static string NameOf(string skinId) =>
        Options.FirstOrDefault(option => option.Id.Equals(skinId, StringComparison.OrdinalIgnoreCase)).Name ?? skinId;

    /// <summary>我们主动切换它的皮肤时用这个：不把自己的回灌当成"玩家在它的界面里改了"。</summary>
    internal static bool ApplyQuiet(string? skinId)
    {
        _echoDepth++;
        CharSelectTakeoverSuppressor.EchoSuppressed = true;
        try
        {
            return Apply(skinId);
        }
        finally
        {
            _echoDepth--;
            CharSelectTakeoverSuppressor.EchoSuppressed = _echoDepth > 0;
        }
    }

    /// <summary>
    /// 用它自己的展示工厂创建一只「选人界面用」的奥斯提精灵（Node2D）。
    /// 它的工厂会校验骨架/动画是否完整，比自己直接加载 .tres 稳得多——
    /// 我们之前直接加载 display_select.tres，SpineSprite 一直建不出骨架（预览空白）。
    /// 失败返回 null，调用方可以回退到普通加载。
    /// </summary>
    internal static Node2D? CreateSelectDisplay()
    {
        Resolve();
        if (_assembly == null)
        {
            return null;
        }

        try
        {
            var factory = _assembly.GetType("OstyDefectImpostor.DisplayResourceFactory", throwOnError: false);
            var create = factory?.GetMethod(
                "Create",
                BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic,
                binder: null,
                types: [typeof(bool)],
                modifiers: null);
            if (create == null)
            {
                return null;
            }

            return create.Invoke(null, [true]) as Node2D;
        }
        catch (Exception exception)
        {
            ModLog.Warn($"[奥斯提] 用它自己的展示工厂创建预览失败：{exception.GetBaseException().Message}");
            return null;
        }
    }

    /// <summary>它自己的展示精灵使用的待机动画名。</summary>
    internal const string SelectDisplayAnimation = "animation";

    /// <summary>把它的奥斯提外观切到指定皮肤；skinId 为空/未知时切回原版。</summary>
    internal static bool Apply(string? skinId)
    {
        Resolve();
        if (_selectionType == null)
        {
            return false;
        }

        var target = string.IsNullOrEmpty(skinId) ? VanillaSkinId : skinId;
        try
        {
            var method = _selectionType.GetMethod(
                "Apply",
                BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic,
                binder: null,
                types: [typeof(string)],
                modifiers: null);
            if (method == null)
            {
                return false;
            }

            return method.Invoke(null, [target]) is true;
        }
        catch (Exception exception)
        {
            ModLog.Warn($"[奥斯提] 切换 {AssemblyName} 皮肤失败：{exception.GetBaseException().Message}");
            return false;
        }
    }
}
