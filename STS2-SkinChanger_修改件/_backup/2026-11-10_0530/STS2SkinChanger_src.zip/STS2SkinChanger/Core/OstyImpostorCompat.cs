using System.Reflection;

namespace STS2SkinChanger.Core;

/// <summary>
/// Compatibility guard for the "让鸡煲撑在地上假装自己是奥斯提" (OstyDefectImpostor, id 3820801911) mod.
///
/// That mod discards the vanilla Osty body branch and installs its own unique <c>SpineSprite</c>
/// (its log: "Replaced full body branch with genuine unique SpineSprite inside an identity body
/// group"). A skin that also ships <c>osty</c> resources is mounted by this mod as a replacement
/// resource pack, so the two owners race for the same skeleton, atlas and textures: the impostor's
/// sprite ends up textured by the skin pack (or with no atlas at all — Custom Skeleton Loader prints
/// "No atlas found for: osty"), which is what made Osty turn dark as soon as an attack forced the
/// visual to be rebuilt, and stay dark afterwards.
///
/// Since the impostor owns that creature outright, the Skin Changer stops mounting skin resources
/// for the <c>osty</c> group while that mod is installed. The player still gets every other skin;
/// only the summon keeps the impostor's own appearance.
/// </summary>
internal static class OstyImpostorCompat
{
    private const string AssemblyName = "OstyDefectImpostor";
    private const string GroupId = "osty";

    private static readonly HashSet<string> ReportedGroups = new(StringComparer.OrdinalIgnoreCase);
    private static bool _resolved;
    private static bool _installed;

    /// <summary>True when the impostor mod's assembly is loaded in this process.</summary>
    internal static bool IsInstalled
    {
        get
        {
            if (_resolved)
            {
                return _installed;
            }

            _resolved = true;
            _installed = false;
            foreach (var assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                // 只按程序集名判断。枚举类型（GetTypes()/读类型属性）极不安全：
                // 别的 Mod 会引用缺失依赖（GodotSharp / sts2 / BaseLib），甚至个别程序集
                // 含"无法加载的类型"（例如 Steamworks.NET 的 OptionValue），读它们的
                // Namespace 会直接抛 TypeLoadException，导致整个初始化失败。
                // 这个 Mod 的程序集名是稳定的 "OstyDefectImpostor"，用名字就够了。
                string? name;
                try
                {
                    name = assembly.GetName()?.Name;
                }
                catch
                {
                    continue;
                }

                if (string.Equals(name, AssemblyName, StringComparison.OrdinalIgnoreCase))
                {
                    _installed = true;
                    break;
                }
            }

            if (_installed)
            {
                ModLog.Info(
                    $"检测到 {AssemblyName}：它的 Osty 本体是自建 SpineSprite，" +
                    "皮肤切换器不再为 osty 挂载皮肤资源，避免两边争同一个骨骼/贴图（此前会导致 Osty 变黑且不恢复）。");
            }

            return _installed;
        }
    }

    /// <summary>
    /// 玩家是否已经把随从外观当成独立选项（在「奥斯提下拉」里选过）。
    /// 为 false 时保留旧行为：这个 Mod 装了就把 osty 让给它（避免两边争同一只骨骼变黑）；
    /// 为 true 时 osty 完全由本 Mod 的选择决定，它只在玩家主动选它的皮肤时接管。
    /// </summary>
    internal static bool Decoupled { get; set; }

    /// <summary>Whether the Skin Changer must leave this appearance group to the other mod.</summary>
    internal static bool MustDefer(string groupId)
    {
        if (!groupId.Equals(GroupId, StringComparison.OrdinalIgnoreCase) || !IsInstalled)
        {
            return false;
        }

        // 已经解耦：由「奥斯提下拉」的选择决定，选到它的皮肤时 osty 组回到游戏原版，
        // 本身就没有资源要挂，不需要再让位。
        if (Decoupled)
        {
            return false;
        }

        if (ReportedGroups.Add(groupId))
        {
            ModLog.Info($"osty 的外观交回 {AssemblyName}（该召唤由它的自建骨骼负责）。");
        }

        return true;
    }
}
