using System.Reflection;
using System.Runtime.Loader;

namespace STS2SkinChanger.Core;

/// <summary>
/// Loads a second skin package whose assembly identity is already taken by another package.
///
/// Two packs can be the same code base re-exported (Joan <c>0.3.5-S</c> and <c>0.3.6</c> both declare
/// <c>JoanofArcIroncladHpwear, Version=0.3.5.0</c>). The default load context can only hold one of
/// them, so the Skin Changer used to keep the duplicate as a resource-only "delta" package: its models
/// and textures were mounted, but its code never ran. That is why, with both installed, the pack that
/// lost the race had no hotkey, no damage stages and no portrait sync — it looked "as good as dead".
///
/// A separate <see cref="AssemblyLoadContext"/> can hold the second copy: the identity is scoped per
/// context. Every reference (GodotSharp, sts2, 0Harmony, the Skin Changer itself) is resolved by the
/// default context, so both copies share the same Harmony instance and the same game types — only their
/// own static state is separate, which is exactly what "two packs must not share state" requires.
///
/// Which copy acts on a frame is decided by <see cref="ProviderMenuGateCompat"/> from the current
/// selection, so both can be loaded without fighting over the character.
/// </summary>
internal static class IsolatedDuplicateProviderLoader
{
    private static readonly object Sync = new();
    private static readonly Dictionary<string, ProviderLoadContext> Contexts =
        new(StringComparer.OrdinalIgnoreCase);

    /// <summary>
    /// Loads the provider assembly from a stream into its own load context. Returns null when the
    /// stream cannot be read; the caller then keeps the old "resources only" behaviour.
    /// </summary>
    internal static Assembly? Load(string providerId, string assemblyPath, Stream assemblyStream)
    {
        if (string.IsNullOrWhiteSpace(providerId) || assemblyStream == null)
        {
            return null;
        }

        try
        {
            lock (Sync)
            {
                if (!Contexts.TryGetValue(providerId, out var context))
                {
                    context = new ProviderLoadContext(providerId);
                    Contexts[providerId] = context;
                }

                var assembly = context.LoadFromStream(assemblyStream);
                ModLog.Info(
                    $"已把同源皮肤包 {Path.GetFileName(assemblyPath)} 载入独立程序集域（{providerId}）：" +
                    "它的代码会正常执行，和占用同名程序集的另一份互不共享状态。");
                return assembly;
            }
        }
        catch (Exception exception)
        {
            ModLog.Warn(
                $"把同源皮肤包 {Path.GetFileName(assemblyPath)} 载入独立程序集域失败，" +
                "将退回只接管资源（不执行代码）：" + exception.GetBaseException().Message);
            return null;
        }
    }

    internal static bool IsIsolated(Assembly assembly) =>
        AssemblyLoadContext.GetLoadContext(assembly) is ProviderLoadContext;

    /// <summary>Path-based variant for packages whose bytes need no rewriting.</summary>
    internal static Assembly? LoadFromPath(string providerId, string assemblyPath)
    {
        try
        {
            lock (Sync)
            {
                if (!Contexts.TryGetValue(providerId, out var context))
                {
                    context = new ProviderLoadContext(providerId);
                    Contexts[providerId] = context;
                }

                var assembly = context.LoadFromAssemblyPath(assemblyPath);
                ModLog.Info(
                    $"已把同源皮肤包 {Path.GetFileName(assemblyPath)} 载入独立程序集域（{providerId}）：" +
                    "它的代码会正常执行，和占用同名程序集的另一份互不共享状态。");
                return assembly;
            }
        }
        catch (Exception exception)
        {
            ModLog.Warn(
                $"把同源皮肤包 {Path.GetFileName(assemblyPath)} 载入独立程序集域失败，" +
                "将退回只接管资源（不执行代码）：" + exception.GetBaseException().Message);
            return null;
        }
    }

    /// <summary>Only the duplicate copy gets its own context; everything else falls through to default.</summary>
    private sealed class ProviderLoadContext(string providerId) : AssemblyLoadContext(
        $"skin-provider-{providerId}",
        isCollectible: false)
    {
        protected override Assembly? Load(AssemblyName assemblyName) => null;
    }
}
