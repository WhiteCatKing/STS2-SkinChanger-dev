using System.Reflection;
using HarmonyLib;
using STS2SkinChanger.Catalog;

namespace STS2SkinChanger.Core;

/// <summary>
/// Skin packs may refuse to touch the character-select presentation when the Skin Changer is present
/// but the selected provider is not literally their own id. The Joan packs do exactly that: their
/// <c>SkinSelectionGate</c> asks the Skin Changer for <c>GetSelectedRuntimeProvider("ironclad")</c> and
/// only proceeds when it reads back <c>JoanofArcIroncladHpwear</c>.
/// <para>
/// The 0.3.5-S re-export is registered under <c>JoanofArcIroncladHpwear111</c>, so that comparison
/// fails and the pack switches off its own menu-portrait sync, its in-run portrait sync and its
/// appearance hotkey — visible as “the avatar never changes” and “the quick-switch key does nothing”,
/// even though the same code works in the 0.3.6 package.
/// </para>
/// <para>
/// A re-export that shares the whole variant contract is the same skin, so the gate is allowed to
/// answer “yes” while one of that contract's variants is selected. Every other selection keeps the
/// pack's own answer, so a genuinely different Ironclad skin still leaves the pack disabled.
/// </para>
/// </summary>
internal static class ProviderMenuGateCompat
{
    private const string GateTypeName = "SkinSelectionGate";

    private static readonly HashSet<string> Patched = new(StringComparer.OrdinalIgnoreCase);
    private static double _nextScan;

    /// <summary>Installs the gate patch for every loaded package that exposes a variant contract.</summary>
    internal static void Tick(double delta)
    {
        _nextScan -= delta;
        if (_nextScan > 0)
        {
            return;
        }

        _nextScan = 1d;

        try
        {
            foreach (var contract in VariantContracts())
            {
                if (!ManagedSkinModLoader.TryGetLoadedProviderAssembly(contract.AssemblyPath, out var assembly) ||
                    assembly == null ||
                    !Patched.Add(contract.AssemblyPath))
                {
                    continue;
                }

                PatchGate(contract, assembly);
            }
        }
        catch (Exception exception)
        {
            ModLog.Warn("检查皮肤包选人界面接管门控失败：" + exception.GetBaseException().Message);
        }
    }

    private static IEnumerable<ProviderSettingsVariantOptions.SettingsVariantContract> VariantContracts() =>
        ProviderSettingsVariantOptions.Slots()
            .Select(slot => slot.Contract)
            .DistinctBy(contract => contract.AssemblyPath, StringComparer.OrdinalIgnoreCase);

    private static void PatchGate(
        ProviderSettingsVariantOptions.SettingsVariantContract pack,
        Assembly assembly)
    {
        Type? gate = null;
        foreach (var type in SafeTypes(assembly))
        {
            if (type?.Name is GateTypeName or "SkinSelectionGate")
            {
                gate = type;
                break;
            }
        }

        if (gate == null)
        {
            return;
        }

        var patched = 0;
        foreach (var name in new[] { "MenuAllowed", "SceneAllowed", "PlayerAllowed" })
        {
            var method = gate.GetMethod(
                name,
                BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
            if (method == null || method.ReturnType != typeof(bool))
            {
                continue;
            }

            try
            {
                new Harmony(Entry.ModId + ".variant-gate")
                    .Patch(
                        method,
                        postfix: new HarmonyMethod(
                            typeof(ProviderMenuGateCompat),
                            nameof(AllowWhenSiblingVariantSelected)));
                patched++;
            }
            catch (Exception exception)
            {
                ModLog.Warn(
                    $"放行皮肤包 {Path.GetFileName(pack.AssemblyPath)} 的选人界面门控失败：" +
                    exception.GetBaseException().Message);
            }
        }

        if (patched > 0)
        {
            ModLog.Info(
                $"已放行 {Path.GetFileName(pack.AssemblyPath)} 的选人界面/头像门控：" +
                "选中同源包的变体时，它自己的选人头像、局内头像与外观快捷键照常工作。");
        }

        PatchOwnClickCycle(pack, assembly);
    }

    /// <summary>
    /// Keeps the pack's own "act on the character" entry points to the package that actually owns the
    /// selection. With both packs now loaded side by side, the pack that is <b>not</b> selected must not
    /// swap its damage stages onto the other model, and its palette refresh must not repaint it either.
    /// </summary>
    private static void PatchOwnClickCycle(
        ProviderSettingsVariantOptions.SettingsVariantContract pack,
        Assembly assembly)
    {
        var targets = new (string TypeName, string[] Methods)[]
        {
            ("CharSelectCycle", ["Attach", "OnInput"]),
            ("Palette", ["RefreshAppearance"])
        };

        var perTarget = new Harmony(Entry.ModId + ".variant-own-selection");
        var patched = 0;
        foreach (var type in SafeTypes(assembly))
        {
            if (type == null)
            {
                continue;
            }

            var entry = targets.FirstOrDefault(candidate => candidate.TypeName == type.Name);
            if (entry.Methods == null)
            {
                continue;
            }

            foreach (var name in entry.Methods)
            {
                var method = type.GetMethod(
                    name,
                    BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
                if (method == null)
                {
                    continue;
                }

                try
                {
                    perTarget.Patch(
                        method,
                        prefix: new HarmonyMethod(typeof(ProviderMenuGateCompat), nameof(AllowOnlyForOwnSelection)));
                    patched++;
                }
                catch
                {
                    // Optional guard: the pack's behaviour simply stays as it is.
                }
            }
        }

        if (patched > 0)
        {
            ModLog.Info(
                $"已锁定 {Path.GetFileName(pack.AssemblyPath)} 的“只在它自己被选中时动作”：" +
                "点角色切形态与调色板刷新不会作用到另一个同源皮肤包上。");
        }
    }

    /// <summary>
    /// Runs before the pack's click handler. Returns false when another package owns the current
    /// Ironclad selection, so the pack cannot swap its own stages onto that package's model.
    /// </summary>
    private static bool AllowOnlyForOwnSelection(MethodBase __originalMethod)
    {
        try
        {
            var assembly = __originalMethod?.DeclaringType?.Assembly;
            if (assembly == null ||
                !ManagedSkinModLoader.TryGetLoadedProviderPath(assembly, out var assemblyPath) ||
                ProviderSettingsVariantOptions.ContractForAssembly(assemblyPath) is not { } pack)
            {
                return true;
            }

            var selected = ProviderSettingsVariantOptions.ContractOf(
                SkinService.GetCharacterSelectionOptionId("ironclad"));
            if (selected == null)
            {
                return true;
            }

            return selected.AssemblyPath.Equals(pack.AssemblyPath, StringComparison.OrdinalIgnoreCase);
        }
        catch
        {
            return true;
        }
    }

    private static void AllowWhenSiblingVariantSelected(
        ref bool __result,
        MethodBase __originalMethod)
    {
        if (__result)
        {
            return;
        }

        try
        {
            var assembly = __originalMethod?.DeclaringType?.Assembly;
            if (assembly == null ||
                !ManagedSkinModLoader.TryGetLoadedProviderPath(assembly, out var assemblyPath) ||
                ProviderSettingsVariantOptions.ContractForAssembly(assemblyPath) is not { } pack)
            {
                return;
            }

            foreach (var pair in SkinService.Config.Selections)
            {
                var contract = ProviderSettingsVariantOptions.ContractOf(pair.Value);
                if (contract == null)
                {
                    continue;
                }

                // This package owns the current selection: its portraits, its hotkey and its click
                // cycling are all correct, so let it through.
                if (contract.AssemblyPath.Equals(pack.AssemblyPath, StringComparison.OrdinalIgnoreCase))
                {
                    __result = true;
                    return;
                }

                // Fallback for the case the package could not be loaded at all (identity conflict
                // without an isolated context): a same-contract package acts on its behalf.
                if (ProviderSettingsVariantOptions.SharesContractShape(contract, pack) &&
                    !ProviderSettingsVariantOptions.IsPackageLoaded(contract))
                {
                    __result = true;
                    return;
                }
            }
        }
        catch
        {
            // A compatibility patch must never change the pack's answer when it cannot decide.
        }
    }

    private static IEnumerable<Type?> SafeTypes(Assembly assembly)
    {
        try
        {
            return assembly.GetTypes();
        }
        catch (ReflectionTypeLoadException exception)
        {
            return exception.Types;
        }
        catch
        {
            return [];
        }
    }
}
